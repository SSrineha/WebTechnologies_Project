var Product=require('../models/product');
var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/shopping',{useNewUrlParser:true});

var products=[
    new Product({
        imagePath:'https://www.kannadastore.com/images/Gems-of-Thyagaraja-MS-Subbulakshmi.jpg',
        title:'Gems of thyagaraja',
        description:'by M.S. subbulakshmi',
        price:1000
       }),
       new Product({ 
        imagePath:'https://m.media-amazon.com/images/I/812ecIR9+5L._AC_UL654_FMwebp_QL65_.jpg',
        title:'Raaga Sudha Rasa (4 GB)',
        description:'by Dr. M. Balamuralikrishna',
        price:300
       }),
       new Product({ 
        imagePath:'https://m.media-amazon.com/images/I/81SaRVAh4qL._AC_UL654_FMwebp_QL65_.jpg',
        title:'Vedukondama - 320 kbps MP3 Audio (4 GB)',
        description:'by S.P. Balasubrahmanyam, S. Janaki, et al.',
        price:200
       }),
       new Product({ 
        imagePath:'https://m.media-amazon.com/images/I/81qyuHkIEZL._AC_UL654_FMwebp_QL65_.jpg',
        title:' Vallamai Ullavan - 320 kbps MP3 Audio (4 GB) ',
        description:'by S. Janaki, Seergazhi G. Sivachidambaram,',
        price:200
       }),
   
       new Product({ 
        imagePath:'https://m.media-amazon.com/images/I/71zAdqpDYkL._AC_UL654_FMwebp_QL65_.jpg',
        title:'Haunting Melodies - Malyalam',
        description:'by S. Janaki ',
        price:200
       }),
       new Product({ 
        imagePath:'https://m.media-amazon.com/images/I/51qyE30en4L._AC_UL654_FMwebp_QL65_.jpg',
        title:'Best of Ilaiyaraaja',
        description:'by S. Janaki and illayaraaja',
        price:200
       })
     
    ];

    var done=0;
    for(var i=0;i<products.length;i++)
    {
        products[i].save(function(err,result){
            if (err) return console.error(err);
            done++;
            if(done===products.length)
            {
                
                exit();
            }
        });
    }
    function exit()
    {
        mongoose.disconnect();
    }

   